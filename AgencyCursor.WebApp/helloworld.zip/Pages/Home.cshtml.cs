using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AgencyCursor.Pages;

public class HomeModel : PageModel
{
    public void OnGet()
    {
    }
}
