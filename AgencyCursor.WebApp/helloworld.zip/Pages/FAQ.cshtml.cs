using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AgencyCursor.Pages;

public class FAQModel : PageModel
{
    public void OnGet()
    {
    }
}
